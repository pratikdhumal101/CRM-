export * from './customer-list.component';
export * from './customer-form.component';

export * from './customer.service';
export * from './customer.module';
export * from './customer'