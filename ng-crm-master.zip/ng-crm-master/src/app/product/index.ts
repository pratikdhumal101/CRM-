export * from './product-list.component';
export * from './product-form.component';

export * from './product.service';
export * from './product.module';
export * from './product'